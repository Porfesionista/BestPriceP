function toggleSettings() {
    var settingsMenu = document.querySelector('.settings-menu');
    settingsMenu.classList.toggle('show'); // Agrega o quita la clase 'show' para mostrar u ocultar el menú
}
